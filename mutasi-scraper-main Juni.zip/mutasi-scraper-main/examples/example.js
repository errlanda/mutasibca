// SCRIPT ini saat ini 0% BUG. Tanyakan dulu sama Erland 088989054639 jika mau merubahnya.
// Klik BCA seringkali gagal login, karena bug dari sistem BCA sendiri. Jadi script ini dibuat supaya terus menerus menghajar tanpa henti meskipun error lanjut.
import { ScrapBCA } from "mutasi-scraper";
import { BCAParser } from "../src/helper/utils/Parser";
import axios from "axios"; // Import axios
"use strict";

// Fungsi penundaan kustom
function delay(time) {
  return new Promise(resolve => setTimeout(resolve, time));
}

const user = "erlandac1002"; // usernamenya akun bank
const pass = "xxxxxxxxxxxx"; // passwordnya akun bank
const norek = "2711437667"; // pasti nomor rekeningnya, siapa tau mau donasi monggo

async function runScraper() {
  const scraper = new ScrapBCA(user, pass, norek, {
    headless: true,
    args: [
      "--log-level=3",
      "--no-default-browser-check",
      "--disable-infobars",
      "--disable-web-security",
      "--disable-site-isolation-trials", 
"--no-sandbox"
    ],
  });

  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 8); //dibuat minus berapa hari

  const tglawal = yesterday.getDate(); // Tanggal kemarin
  let blnawal = yesterday.getMonth() + 1; // Bulan kemarin (perlu ditambah 1 karena Januari dimulai dari 0)
  const tglakhir = today.getDate(); // Tanggal hari ini
  const blnakhir = today.getMonth() + 1; // Bulan saat ini (perlu ditambah 1 karena Januari dimulai dari 0)

  // Jika kemarin adalah bulan sebelumnya
  if (tglawal > today.getDate()) {
    blnawal = today.getMonth(); // Atur bulan awal ke bulan sebelumnya
    if (blnawal === 0) { // Jika bulan awal menjadi Januari (0), atur ke Desember (12)
      blnawal = 12;
    }
  }

// di sini bisa ditambahkan pengaturan

  try {
    await scraper.loginToBCA();
    await delay(2000); // Jeda 2 detik setelah login
    const mutasinya = await scraper.selectAccountAndSetDates(tglawal, blnawal, tglakhir, blnakhir);
    await delay(2000); // Jeda 2 detik setelah memilih tanggal

    // Ambil HTML dari halaman
    const htmlContent = await mutasinya.content();
    await delay(2000);

    // Proses HTML dengan BCAParser
    const selectors = {
      accountNoField: 'font:contains("Nomor Rekening")',
      nameField: 'font:contains("Nama")',
      periodeField: 'font:contains("Periode")',
      mataUangField: 'font:contains("Mata Uang")',
      transactionsTable: 'table[border="1"]',
      settlementTable: 'table[border="0"][width="70%"]',
    };

    const bcaParser = new BCAParser(htmlContent, selectors);
    const result = bcaParser.parse();
    console.log(result);

    // Kirim hasil parsing ke endpoint URL bot
    const mutasiMasuk = result.mutasi.filter(item => item.mutasi === 'CR');

    for (const item of mutasiMasuk) {
      let referenceId2 = item.nominal.replace(/,/g, ''); // Menghilangkan koma dari nominal
      referenceId2 = referenceId2.split('.')[0]; // Menghapus titik dan angka setelah titik

      // Kirim ke endpoint pertama
      await axios.post('https://wa.erland.biz.id/mutasi', { reference_id2 : referenceId2 })
        .then(response => {
          console.log('Data berhasil dikirim ke wa BOT:', response.data);
        })
        .catch(error => {
          console.error('Error mengirim data:', error);
        });

      // Kirim ke endpoint kedua
      await axios.post('https://hazline.com/endpoint/', { number: referenceId2 })
        .then(response => {
          console.log('Data berhasil dikirim ke hazline:', response.data);
        })
        .catch(error => {
          console.error('Error mengirim data ke hazline:', error);
        });
    }

    await delay(5000); // Jeda 5 detik sebelum logout
    // Logout dan tutup sesi setelah parsing selesai
    await scraper.logoutAndClose();
    console.log("Task completed successfully.");

    runScraper(); // Restart the process
  } catch (error) {
    console.error("Error: ", error);
    

    if (error.message.includes("Anda dapat melakukan login kembali setelah 5 menit") || 
    error.message.includes("You can re-login after 5 minutes")) {
  await scraper.logoutAndClose();
  console.log("Re-login required. Waiting for 5 minutes before retrying.");

  
  await delay(300000); // Jeda 5 menit (300.000 milidetik)
} else {
  await scraper.logoutAndClose();
}


    await scraper.logoutAndClose();
    runScraper(); // Restart the process after an error
  }
}

runScraper();