import ScrapBCA from './bank/BCA.class';
import ScrapBNI from './bank/BNI.class';
import ScrapMCM from './bank/MCM.class';
import ScrapBRI from './bank/BRI.class';
import ScrapBSI from './bank/BSI.class';

export {
    ScrapBCA,
    ScrapBNI,
    ScrapMCM,
    ScrapBRI,
    ScrapBSI
};