export interface ConfigBrowser {
    headless: boolean | "new";
    args: string[];
    executablePath: any;
  }