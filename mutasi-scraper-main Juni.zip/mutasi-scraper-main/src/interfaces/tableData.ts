export interface tableData {
    tanggal: any;
    keterangan: any;
    nama: any;
    mutasi: any;
    nominal: any;
    saldoakhir: any;
}

export interface profile {
    title: any;
    value : any;
}